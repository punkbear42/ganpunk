from tensorflow import keras
from helper import generate_fake_samples, save_punk

def evaluate(epoch, latent_dim, n_samples):
	filename = 'results/generator_model_%03d_020.h5' % (epoch)
	g_model = keras.models.load_model(filename)
	x_fake, y_fake = generate_fake_samples(g_model, latent_dim, 1)
	save_punk(x_fake[0], epoch, 0, 1)

n_samples = 1
latent_dim = 100
evaluate(485, latent_dim, n_samples)