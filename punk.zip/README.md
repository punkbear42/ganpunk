splitting punks: ./magick convert /home/yann/punk/punks.png -crop 24x24  +repage  +adjoin  punk_%02d.png


